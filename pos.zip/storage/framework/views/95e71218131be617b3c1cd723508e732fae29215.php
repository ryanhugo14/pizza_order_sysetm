<?php $__env->startSection('title', 'Order List'); ?>

<?php $__env->startSection('content'); ?>

    <div class="p-3 pt-10 md:p-8 lg:p-16 ">
        <div class="mt-5 flex flex-col md:flex-row md:justify-between md:items-center space-y-3 md:space-y-0">
            <div class="flex items-center">
                <h3 class="text-xl font-semibold flex md:justify-center items-center">Total -</h3>
                <h3
                    class="text-xl font-semibold ml-2 bg-black rounded-full w-9 h-9 text-white flex items-center justify-center">
                    <span></span><?php echo e($users->total()); ?>

                </h3>
            </div>
            <form action="<?php echo e(route('order#sortingStatus')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <div class="flex">
                    <input name="key" type="text" placeholder="Search" value="<?php echo e(request('key')); ?>"
                        class="px-5 py-2 focus:ring-0  rounded-r-none rounded-lg focus:border-yellow-500">
                    <button type="submit" class="px-3 py-2 bg-black text-white rounded-l-none rounded-lg">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </form>
        </div>


        <?php if(count($users) != 0): ?>
            <div class=" overflow-x-scroll lg:overflow-visible">
                <table class="mt-5 lg:mt-10  text-center table-auto w-[150%] md:w-[120%] lg:w-[100%]" id="dataTable">
                    <tr class="columns-12">
                        <th class="uppercase text-[12px] md:text-sm lg:text-lg cursor-default">Image</th>
                        <th class="uppercase text-[12px] md:text-sm lg:text-lg cursor-default">Name</th>
                        <th class="uppercase text-[12px] md:text-sm lg:text-lg cursor-default">Email</th>
                        <th class="uppercase text-[12px] md:text-sm lg:text-lg cursor-default">Address</th>
                        <th class="uppercase text-[12px] md:text-sm lg:text-lg cursor-default">Gender</th>
                        <th class="uppercase text-[12px] md:text-sm lg:text-lg cursor-default">Role</th>
                        <th class=""></th>
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border columns-12 h-20 lg:h-32">
                            <input type="hidden" value="<?php echo e($u->id); ?>" id="userId">
                            <td class="text-[12px] md:text-sm lg:text-lg cursor-default">
                                <?php if($u->image == null): ?>
                                    <?php if($u->gender == 'male'): ?>
                                        <img src="<?php echo e(asset('image/default_male.jpg')); ?>" alt=""
                                            class="bg-contain w-20 md:w-28 lg:w-32 mx-auto">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('image/default_female.jpg')); ?>" alt=""
                                            class="bg-contain w-20 md:w-28 lg:w-32 mx-auto">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('storage/' . $u->image)); ?>" alt=""
                                        class="bg-contain w-20 md:w-28 lg:w-32 mx-auto">
                                <?php endif; ?>
                            </td>
                            <td class="text-[12px] md:text-sm lg:text-lg cursor-default"><?php echo e($u->name); ?></td>
                            <td class="text-[12px] md:text-sm lg:text-lg cursor-default"><?php echo e($u->email); ?></td>
                            <td class="text-[12px] md:text-sm lg:text-lg cursor-default"><?php echo e($u->address); ?></td>
                            <td class="text-[12px] md:text-sm lg:text-lg cursor-default capitalize"><?php echo e($u->gender); ?>

                            </td>
                            <td class=" cursor-default">
                                <select name="role" id="role"
                                    class="border-none shadow-lg text-[12px] md:text-sm lg:text-lg">
                                    <option value="admin" <?php if($u->role == 'admin'): ?> selected <?php endif; ?>>Admin</option>
                                    <option value="user" <?php if($u->role == 'user'): ?> selected <?php endif; ?>>User</option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="mt-5">
                <?php echo e($users->links()); ?>

            </div>
        <?php else: ?>
            <h1 class="text-5xl font-bold text-slate-500 mt-20 text-center">There is no User here.</h1>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#role').change(function() {
                $role = $('#role').val();
                $parentNode = $(this).parents('tr');
                $userId = $parentNode.find('#userId').val();
                $data = {
                    'role': $role,
                    'userId': $userId
                }


                $.ajax({
                    type: 'get',
                    url: 'http://localhost:8000/user/role/change',
                    data: $data,
                    dataType: 'json',
                    success: function(response) {
                        console.log(response);
                        if (response[0].status == 'success') {
                            window.location.href = "http://localhost:8000/user/list";
                        }
                    }
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\pizza_order_system\resources\views/admin/other/userList.blade.php ENDPATH**/ ?>