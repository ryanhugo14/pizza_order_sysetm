<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="logo" href="<?php echo e(asset('admin/assets/img/—Pngtree—pizza clipart a slice of_5600702.png')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
</head>

<body class="overflow-x-hidden">
    <div class="flex h-screen bg-gray-100" :class="{ 'overflow-hidden': isSideMenuOpen }">
        <!-- sidebar s -->
        <aside class="z-20 hidden md:block w-64 bg-white flex-shrink-0 overflow-y-auto ">
            <!-- logo -->
            <div class="flex items-center ml-3">
                <img src="<?php echo e(asset('admin/assets/img/—Pngtree—pizza clipart a slice of_5600702.png')); ?>" style="width: 80px;" class="" alt="">
                <h4 class="text-2xl font-semibold">PizzaShop</h4>
            </div>
            <!-- menu -->
            <ul class="mt-10">
                <li class="relative flex items-center space-x-5 font-semibold cursor-pointer text-gray-500 hover:text-black h-14">
                    <span class="absolute  inset-y-0 left-0 w-1 bg-yellow-500 rounded-tr-lg rounded-br-lg" aria-hidden="true"></span>
                    <i class="fa-solid fa-house"></i>
                    <span>Dashboard</span>
                </li>
            </ul>
        </aside>
        <!-- siderbar e -->

        <!-- mobile sidebar s -->
        <div class="fixed inset-0 z-10 hidden items-end bg-black bg-opacity-50 sm:items-center sm:justify-center  md:hidden " id="backgrounBlack"></div>
        <aside class="fixed inset-y-0 z-20 flex-shrink-0 w-64 mt-16 overflow-y-auto bg-white hidden  md:hidden" id="sideBar">
            <div class="py-4 text-gray-500 ">
                <div class="flex items-center ml-3">
                    <img src="/assets/img/—Pngtree—pizza clipart a slice of_5600702.png" style="width: 50px;" class="" alt="">
                    <h4 class="text-2xl font-semibold text-black">PizzaShop</h4>
                </div>
                <ul class="mt-6">
                    <li class="relative px-6 py-3">
                        <span class="absolute inset-y-0 left-0 w-1 bg-yellow-500 rounded-tr-lg rounded-br-lg" aria-hidden="true"></span>
                        <a class="inline-flex items-center w-full text-sm font-semibold text-gray-800 transition-colors duration-150 hover:text-gray-800  " href="index.html">
                            <i class="fa-solid fa-house"></i>
                            <span class="ml-4">Dashboard</span>
                        </a>
                    </li>
                </ul>
            </div>
        </aside>
        <!-- mobile siderbar e -->

        <!-- navbar s -->
        <div class="flex flex-col flex-1 w-full">
            <header class="z-10  py-4 bg-white">
                <div class="container flex items-center justify-between h-full px-6 mx-auto">
                    <!-- Mobile hamburger -->
                    <div class="md:hidden flex items-center space-x-5">
                        <div>
                            <button class="p-1 mr-5 -ml-1 rounded-md md:hidden w-10" id="siderBarOpen">
                                <i class="fa-solid fa-bars text-lg text-slate-800"></i>
                            </button>
                            <button class="p-1 mr-5 -ml-1 rounded-md hidden md:hidden w-10" id="siderBarClose">
                                <i class="fa-solid fa-xmark text-lg text-slate-800"></i>
                            </button>
                        </div>
                        <div>
                            <button class="relative">
                                <i class="fa-solid fa-cart-shopping text-xl"></i>
                                <div class="h-4 w-5 bg-yellow-500 rounded-3xl absolute -top-3 -right-6 text-xs font-semibold">2</div>
                            </button>
                        </div>
                    </div>
                    <!-- search -->
                    <div class="md:flex items-center space-x-5 hidden">
                        <div class=" md:py-3 pl-5 pr-3 md:pr-5 lg:pr-10 border rounded-3xl focus-within:text-yellow-400 flex items-center">
                            <i class="fa-solid fa-magnifying-glass mr-3 text-lg "></i>
                            <input type="text" placeholder="Search for pizzas" class="focus:outline-none text-lg text-gray-700 border-none focus:ring-0 ring-white">
                        </div>
                        <div>
                            <button class="relative">
                            <i class="fa-solid fa-cart-shopping text-xl"></i>
                                <div class="h-4 w-5 bg-yellow-500 rounded-3xl absolute -top-3 -right-6 text-xs font-semibold">2</div>
                            </button>
                        </div>
                    </div>
                    <!-- profile -->
                    <div class="  cursor-pointer relative" id="dropDownIcon">
                        <div class="flex items-center space-x-3">
                            <img src="<?php echo e(asset('admin/assets/img/Image 20.jpg')); ?>" alt="" class="rounded-full bg-cover w-12 h-12 hidden md:block">
                            <h5 class="font-semibold text-slate-500 text-md ">Ryann</h5>
                        </div>
                        <div class="absolute bg-white p-5 w-48 md:w-60 -left-20 -translate-x-10 lg:-bottom-48 lg:-left-20 space-y-10 hidden" id="dropDownMenu">
                            <a href="#">
                                <div class="flex items-center space-x-5 text-md text-slate-500 hover:text-black font-semibold h-12">
                                    <i class="fa-solid fa-user"></i>
                                    <h3>Profile</h3>
                                </div>
                            </a>
                            <a href="#">
                                <div class="flex items-center space-x-5 text-md text-slate-500 hover:text-black font-semibold h-12">
                                    <i class="fa-solid fa-gear"></i>
                                    <h3>Setting</h3>
                                </div>
                            </a>
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="flex items-center space-x-5 text-md text-slate-500 hover:text-black font-semibold h-12" type="submit">
                                        <i class="fa-solid fa-right-from-bracket"></i>
                                        <h3>Logout</h3>
                                    </button>
                            </form>
                        </div>
                    </div>

</body>
<script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>

</html>
<?php /**PATH C:\Users\user\Desktop\pizza_order_system\resources\views/admin/admin_dashboard.blade.php ENDPATH**/ ?>