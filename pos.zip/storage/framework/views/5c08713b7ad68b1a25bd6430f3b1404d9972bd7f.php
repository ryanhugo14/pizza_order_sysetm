<?php $__env->startSection('title', 'Product Create'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-center relative px-3 md:px-5 lg:px-0 mx-auto md:w-[600px]">
        <a href="<?php echo e(route('product#list')); ?>" class="absolute left-2 md:left-6 lg:left-0 top-10 flex items-center">
            <i class="fa-solid fa-left-long text-xl mr-2"></i>
            <span class="font-semibold">Back</span>
        </a>
        <div class="bg-white rounded-2xl py-16 px-10 mt-20 w-full lg:w-[600px]">
            <h1 class="text-3xl font-semibold border-b pb-5 text-center cursor-default">Create Your Product</h1>
            <form action="<?php echo e(route('product#create')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mt-10">
                    <label for="productName" class="text-lg font-semibold text-slate-600">Name</label>
                    <input type="text" name="productName" id="productName"
                        class="w-full py-3 px-5 mt-3 placeholder:text-md border border-slate-200 rounded-lg focus:ring-0  focus:border-yellow-500 <?php $__errorArgs = ['productName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter Product Name">
                </div>
                <?php $__errorArgs = ['productName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-[#ff0000] text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mt-10">
                    <label for="categoryName" class="text-lg font-semibold text-slate-600">Category</label>
                    <select type="text" name="categoryName" id="categoryName"
                        class="w-full py-3 px-5 mt-3 placeholder:text-md border border-slate-200 rounded-lg focus:ring-0  focus:border-yellow-500 <?php $__errorArgs = ['categoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Seafood...">
                    <option value="" class="py-2">Choose Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" class="py-2"><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php $__errorArgs = ['categoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-[#ff0000] text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mt-10">
                    <label for="description" class="text-lg font-semibold text-slate-600">Description</label>
                    <textarea type="text" cols="30" rows="10" name="description" id="description"
                        class="w-full py-3 px-5 mt-3 placeholder:text-md border border-slate-200 rounded-lg focus:ring-0  focus:border-yellow-500 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter Product's Description"></textarea>
                </div>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-[#ff0000] text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mt-10">
                    <label for="image" class="text-lg font-semibold text-slate-600">Image</label>
                    <input type="file" name="image" id="image"
                        class="block file:py-1 file:bg-slate-200 file:px-2 file:rounded-md file:border-0  file:text-sm file:font-semibold px-3 py-2 border w-72 lg:w-full text-sm rounded-lg bg-white text-slate-600 focus:outline-none ring-0 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                </div>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-[#ff0000] text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mt-10">
                    <label for="price" class="text-lg font-semibold text-slate-600">Price</label>
                    <input type="number" name="price" id="price"
                        class="w-full py-3 px-5 mt-3 placeholder:text-md border border-slate-200 rounded-lg focus:ring-0  focus:border-yellow-500 <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter Product's Price">
                </div>
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-[#ff0000] text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mt-10">
                    <label for="waitingTime" class="text-lg font-semibold text-slate-600">Waiting Time</label>
                    <input type="number" name="waitingTime" id="waitingTime"
                        class="w-full py-3 px-5 mt-3 placeholder:text-md border border-slate-200 rounded-lg focus:ring-0  focus:border-yellow-500 <?php $__errorArgs = ['waitingTime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter Waiting Time">
                </div>
                <?php $__errorArgs = ['waitingTime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-[#ff0000] text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button
                    class="w-full rounded-xl bg-black/90 text-white text-xl font-semibold text-center px-5 py-3 mt-5" type="submit">Create</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\pizza_order_system\resources\views/admin/product/createPage.blade.php ENDPATH**/ ?>