;

<?php $__env->startSection('content'); ?>
<body class="bg-slate-50">
    <section class="flex flex-col lg:flex-row lg:justify-between bg-white shadow-2xl w-11/12 lg:w-10/12 mx-auto mt-8 mb-5 lg:mb-0 lg:mt-14 p-10 lg:px-20 lg:py-14 rounded-3xl">
        <!-- left -->
        <div class="flex flex-col justify-center items-center mx-auto lg:w-[50%] mb-16 lg:mb-0
        ">
            <img src="/assets/img/—Pngtree—pizza clipart a slice of_5600702.png" alt="" class="w-[400px] lg:w-[500px] h-auto">
            <h3 class="text-lg border-b border-spacing-0 border-black cursor-pointer font-bold text-slate-600 hidden lg:block">Create an account
            </h3>
        </div>
        <!-- right -->
        <div class="lg:flex lg:justify-center lg:w-[50%]">
            <div class="w-full md:px-20">
                <h1 class="text-6xl font-bold mb-20 text-center">Login</h1>
                <div class=" border-b  pb-3 mb-10 ">
                    <label for="">
                        <i class="fa-solid fa-user text-lg mr-3"></i>
                    </label>
                    <input type="email" placeholder="Email" class="text-lg focus:outline-none">
                </div>
                <div class=" border-b mb-8 pb-3 ">
                    <label for="">
                        <i class="fa-solid fa-lock text-lg mr-3"></i>
                    </label>
                    <input type="password" placeholder="Password" class="text-lg focus:outline-none">
                </div>
                <div class="mb-10 flex items-center">
                    <input type="checkbox" name="" id="" class="w-4 h-4 mr-3">
                    <span>Remember me</span>
                </div>
                <button class="px-3 py-3 rounded-2xl bg-black text-white font-bold text-lg lg:w-36 w-full mb-20 lg:mb-32">Login</button>
                <div>
                    <h3 class="text-lg border-b border-spacing-0 border-black cursor-pointer font-bold text-slate-600 lg:hidden inline-block mb-5 md:mb-8">
                        Create an account
                    </h3>
                    <br>
                    <span class="block md:inline-block text-lg text-slate-600 font-bold mr-5 mb-3 lg:mb-0">Or login with</span>
                    <a href="">
                        <button class="w-10 h-10 bg-blue-700 text-white rounded-xl mr-2">
                            <i class="fa-brands fa-facebook-f"></i>
                        </button>
                    </a>
                    <a href="">
                        <button class="w-10 h-10 bg-cyan-500 text-white rounded-xl mr-2">
                            <i class="fa-brands fa-twitter"></i>
                        </button>
                    </a>
                    <a href="">
                        <button class="w-10 h-10 bg-red-500 text-white rounded-xl">
                            <i class="fa-brands fa-google"></i>
                        </button>
                    </a>
                </div>
            </div>
        </div>
    </section>
</body>
<?php $__env->startSection; ?>

<?php echo $__env->make('/pizza_order_system/resources/views/layouts/master.blade.php', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\My Project\pizza_order_system\resources\views/login.blade.php ENDPATH**/ ?>